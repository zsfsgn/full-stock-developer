package com.example.demowiththymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowiththymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
