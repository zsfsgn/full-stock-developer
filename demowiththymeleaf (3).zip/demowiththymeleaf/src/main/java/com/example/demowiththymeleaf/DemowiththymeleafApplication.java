package com.example.demowiththymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemowiththymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemowiththymeleafApplication.class, args);
	}

}
