package com.example.demoforselect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demoforselect.model.*;
import com.example.demoforselect.service.AddressService;
import com.example.demoforselect.service.UserService;


@SpringBootApplication
public class DemoforselectApplication {

	
		public static void main(String[] args) {
		SpringApplication.run(DemoforselectApplication.class, args);
       
        
	}
		
}
