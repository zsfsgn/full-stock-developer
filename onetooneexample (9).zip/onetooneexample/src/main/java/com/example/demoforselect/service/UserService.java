package com.example.demoforselect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

import com.example.demoforselect.dao.UserResp;
import com.example.demoforselect.model.Address;
import com.example.demoforselect.model.User;


@Service
public class UserService {
	
	@Autowired
	private UserResp userresp;
	
	public User save(User b) {
		return userresp.save(b);
	}
    @Transactional(readOnly = true)

	  public List<User> getUser() {
		 return userresp.get();
	  }

	
}
