package com.example.demoforselect.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demoforselect.model.Address;
import com.example.demoforselect.model.User;

@Repository
public interface AddressResp extends JpaRepository<Address,Integer>  {

	

}
