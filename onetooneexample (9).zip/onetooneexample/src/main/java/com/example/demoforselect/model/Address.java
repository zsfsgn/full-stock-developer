package com.example.demoforselect.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "address")

public class Address {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int aid;

    private String street;
    private String state;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")

    private User user;

    public Address() {
    }

    public Address(int aid,String state,String street) {
    	this.aid=aid;
        this.street = street;
        this.state=state;
       
    }
    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state=state;
    }    

    
    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }    
	
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
