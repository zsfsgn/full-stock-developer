package com.example.demoforselect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoforselectApplicationTests {

	@Test
	void contextLoads() {
	}

}
