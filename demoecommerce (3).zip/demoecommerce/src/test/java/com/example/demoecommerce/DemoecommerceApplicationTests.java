package com.example.demoecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoecommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
