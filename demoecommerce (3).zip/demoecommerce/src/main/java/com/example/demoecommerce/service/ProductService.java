package com.example.demoecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demoecommerce.dao.*;
import com.example.demoecommerce.model.*;
@Service
public class ProductService {
    @Autowired
    private ProductRepository pr;

    public List<Product> getservice1() {
        return pr.findAll();
    }

    public Optional<Product> getservice2(int id) {
        return pr.findById(id);
                               
    }

    
}