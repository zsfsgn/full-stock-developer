package com.example.demoecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoecommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoecommerceApplication.class, args);
	}

}
