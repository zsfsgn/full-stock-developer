package com.example.demoecommerce.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoecommerce.model.Product;
import com.example.demoecommerce.service.ProductService;

@Controller

public class ProductController {
    @Autowired
    private ProductService ps;

    @GetMapping("/products")
    public String getProducts(Model model) {
        model.addAttribute("products", ps.getservice1());
        return "product-list"; 
        }


    @GetMapping("/products/{id}")
    public String getProduct(@PathVariable int id, Model model) {
        model.addAttribute("product", ps.getservice2(id).orElse(null));
        return "product-details"; 
    }

   
}
