package com.example.demoforselect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoforselect.dao.UserResp;
import com.example.demoforselect.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserResp userresp;
	
	public User save(User b) {
		return userresp.save(b);
	}
	
	
	
}
