package com.example.demoforselect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoforselect.dao.AddressResp;
import com.example.demoforselect.model.Address;
import com.example.demoforselect.model.User;

@Service
public class AddressService {
	
	@Autowired
	AddressResp addresp;
	public Address save(Address b) {
		return addresp.save(b);
		
	}
}
