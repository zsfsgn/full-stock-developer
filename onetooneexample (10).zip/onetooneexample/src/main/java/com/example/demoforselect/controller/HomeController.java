package com.example.demoforselect.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demoforselect.dao.AddressResp;
import com.example.demoforselect.model.Address;
import com.example.demoforselect.model.User;
import com.example.demoforselect.service.AddressService;
import com.example.demoforselect.service.UserService;


@Controller
public class HomeController {
	@Autowired
	UserService u;
	@Autowired
	AddressService as;
	
	@RequestMapping("/")    
	public String index()  
	{     
	return "reg";    
	}    
	
	@RequestMapping("/add")    
	public String index1()  
	{     
	return "Address";    
	}    
	
	
	 @PostMapping("/save1")
	    public String get1(@ModelAttribute("User") User us) {
	        u.save(us);
	        return "Address";
	    }

	 @PostMapping("/save2")
	    public String get2(@ModelAttribute("Address") Address a) {
	        as.save(a);
	        return "Address";
	    }
	
  }
	

