package com.example.eurekamicroserviceexample23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eurekamicroserviceexample23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
