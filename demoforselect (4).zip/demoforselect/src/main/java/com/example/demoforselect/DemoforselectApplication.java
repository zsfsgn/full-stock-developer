package com.example.demoforselect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoforselectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoforselectApplication.class, args);
	}

}
