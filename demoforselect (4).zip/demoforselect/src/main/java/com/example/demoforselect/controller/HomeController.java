package com.example.demoforselect.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.example.demoforselect.model.User;
import com.example.demoforselect.service.UserService;


@Controller
public class HomeController {
	@Autowired
	UserService u;
	
	@RequestMapping("/")    
	public String index()  
	{     
	return "reg";    
	}    
	
	@PostMapping("/save")
	public String get1(@ModelAttribute User b) {
		u.save(b);
		return "success";
	}
	
	@GetMapping("/abc")
	public ModelAndView get2() {
		List<User>list=u.get();
		return new ModelAndView("index","User",list);
	}
	
	@RequestMapping("/abc/{id}")
	public ModelAndView getbyid(@PathVariable("id") int id) {
		User b=u.get1(id);
		return new ModelAndView("index1","User",b);
	}
	
	@RequestMapping("/abc1/{id}")
	public  ModelAndView deletebyid(@PathVariable("id")int id) {
		
		u.get2(id);
		return new ModelAndView("deletepage");
	}
	
	
	@RequestMapping("/abc2/{id}")
	public String editBook(@PathVariable("id") int id,Model model) {
		User b=u.get1(id);
		model.addAttribute("user",b);
		return "editpage";
	}
	
	
	
    }
	

