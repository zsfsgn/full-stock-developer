package com.example.demoforselect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoforselect.dao.UserResp;
import com.example.demoforselect.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserResp userresp;
	
	public void save(User b) {
		userresp.save(b);
	}
	
	
	public List<User> get(){
		return userresp.findAll();
	}
	
	public User get1(int id) {
		return userresp.findById(id).get();
	}
	public void get2(int id) {
		userresp.deleteById(id);
	}
}
