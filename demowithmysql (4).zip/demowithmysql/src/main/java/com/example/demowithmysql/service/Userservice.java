package com.example.demowithmysql.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demowithmysql.dao.UserRespo;
import com.example.demowithmysql.model.User;


@Service
public class Userservice {
	@Autowired
	private UserRespo repo;
	
	public void save(User u) {
		repo.save(u);
	}
	
	
}
