package com.example.demowithmysql.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demowithmysql.model.User;

import com.example.demowithmysql.dao.UserRespo;
import com.example.demowithmysql.service.*;


@Controller
public class HomeController {

	@Autowired
	Userservice abc;
	
	@GetMapping(value="/home")
	public String get()
	{
		return "index";
	}
	@PostMapping("abc")
	public String addUsers(User u)
	{
       
		abc.save(u);
		
		return "result";
	}
	
	
	
}
