package com.example.demowithmysql.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demowithmysql.model.User;


public interface UserRespo extends JpaRepository<User, Integer> {
	
}
