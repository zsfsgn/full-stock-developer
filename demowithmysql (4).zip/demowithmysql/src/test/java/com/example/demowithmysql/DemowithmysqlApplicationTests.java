package com.example.demowithmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowithmysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
